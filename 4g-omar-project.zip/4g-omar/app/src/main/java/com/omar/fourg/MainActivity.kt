package com.omar.fourg

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.PhoneStateListener
import android.telephony.SignalStrength
import android.telephony.TelephonyManager
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var tm: TelephonyManager
    private lateinit var tvNetType: TextView
    private lateinit var tvSignal: TextView
    private lateinit var tvCarrier: TextView
    private lateinit var tvInternet: TextView
    private lateinit var tvDevice: TextView
    private lateinit var tvResult: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var lastDbm: Int? = null
    private var waitingForUser = false

    // تحديث دوري كل 5 ثوانٍ
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 5000)
        }
    }

    private val signalListener = object : PhoneStateListener() {
        @Suppress("DEPRECATION")
        override fun onSignalStrengthsChanged(ss: SignalStrength) {
            lastDbm = readDbm(ss)
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        tvNetType = findViewById(R.id.tvNetType)
        tvSignal = findViewById(R.id.tvSignal)
        tvCarrier = findViewById(R.id.tvCarrier)
        tvInternet = findViewById(R.id.tvInternet)
        tvDevice = findViewById(R.id.tvDevice)
        tvResult = findViewById(R.id.tvResult)

        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 1)
        }

        findViewById<Button>(R.id.btnLock).setOnClickListener { onLockPressed() }
    }

    override fun onResume() {
        super.onResume()
        @Suppress("DEPRECATION")
        tm.listen(signalListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS)
        handler.post(ticker)
        if (waitingForUser) {          // رجع المستخدم من الإعدادات: اعرض النتيجة الحقيقية
            waitingForUser = false
            if (networkType() == 13) {
                tvResult.text = "✅ الشبكة الآن LTE (4G)"
            } else {
                tvResult.text = "❌ لم يتم التفعيل. الشبكة الحالية: ${typeName(networkType())}"
            }
        }
    }

    override fun onPause() {
        super.onPause()
        @Suppress("DEPRECATION")
        tm.listen(signalListener, PhoneStateListener.LISTEN_NONE)
        handler.removeCallbacks(ticker)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refresh()
    }

    private fun onLockPressed() {
        // 1) فحص الجهاز
        if (!isSupportedDevice()) {
            tvResult.text = "⚠️ جهازك غير مُختبر (Honor 6 / Honor 6X فقط)"
        }
        // 2) محاولة فتح شاشة نوع الشبكة. التطبيق لا يملك صلاحية فرض LTE ONLY بنفسه.
        // الأولوية: شاشة "معلومات الهاتف" (RadioInfo) التي فيها "تعيين نوع الشبكة المفضل: LTE only"
        val intents = listOf(
            Intent().setClassName("com.android.phone", "com.android.phone.settings.RadioInfo"),
            Intent().setClassName("com.android.settings", "com.android.settings.RadioInfo"),
            Intent().setClassName("com.android.phone", "com.android.phone.RadioInfo"),
            Intent(Intent.ACTION_MAIN).setClassName("com.android.settings", "com.android.settings.Settings\$TestingSettingsActivity"),
            Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        for (i in intents) {
            try {
                waitingForUser = true
                startActivity(i)
                tvResult.text = "اختر LTE فقط (LTE only) من الإعدادات ثم ارجع للتطبيق"
                return
            } catch (e: Exception) {
                waitingForUser = false
            }
        }
        try {
            // آخر محاولة: نفس الكود *#*#4636#*#*
            sendBroadcast(Intent("android.provider.Telephony.SECRET_CODE", android.net.Uri.parse("android_secret_code://4636")))
            waitingForUser = true
            tvResult.text = "حاولت فتح معلومات الهاتف. إن لم تفتح اطلب *#*#4636#*#* من تطبيق الاتصال"
        } catch (e: Exception) {
            tvResult.text = "❌ تعذّر فتح إعدادات الشبكة على هذا الجهاز"
        }
    }

    private fun isSupportedDevice(): Boolean {
        val m = Build.MODEL.uppercase()
        return m.startsWith("H60") || m.startsWith("BLN")   // Honor 6 / Honor 6X
    }

    private fun refresh() {
        val type = networkType()
        tvNetType.text = "نوع الشبكة: ${typeName(type)}"
        tvCarrier.text = "الشركة: " + (tm.networkOperatorName.takeIf { it.isNotEmpty() } ?: "غير معروف")
        tvSignal.text = lastDbm?.let { "قوة الإشارة: $it dBm" } ?: "قوة الإشارة: غير متاحة"
        tvInternet.text = "الإنترنت: " + if (isOnline()) "متصل" else "غير متصل"
        tvDevice.text = "الجهاز: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})"
        if (!waitingForUser && type != 13 && type != 0 && tvResult.text.isEmpty()) {
            tvResult.text = "لا توجد تغطية 4G حالياً"
        }
    }

    @Suppress("DEPRECATION")
    private fun networkType(): Int = try {
        if (Build.VERSION.SDK_INT >= 24) tm.dataNetworkType else tm.networkType
    } catch (e: SecurityException) {
        0
    }

    @Suppress("DEPRECATION")
    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo?.isConnected == true
    }

    private fun typeName(t: Int) = when (t) {
        13 -> "LTE (4G)"
        20 -> "5G"
        3, 5, 6, 8, 9, 10, 12, 14, 15, 17 -> "3G"
        1, 2, 4, 7, 11, 16 -> "2G"
        else -> "غير معروف"
    }

    @Suppress("DEPRECATION")
    private fun readDbm(ss: SignalStrength): Int? {
        if (Build.VERSION.SDK_INT >= 29) {
            val l = ss.cellSignalStrengths
            if (l.isNotEmpty()) return l[0].dbm
        } else {
            try {
                val v = SignalStrength::class.java.getMethod("getLteDbm").invoke(ss) as Int
                if (v in -140..-43) return v
            } catch (e: Exception) { }
            if (ss.isGsm) {
                val asu = ss.gsmSignalStrength
                if (asu in 0..31) return -113 + 2 * asu
            }
        }
        return null
    }
}
